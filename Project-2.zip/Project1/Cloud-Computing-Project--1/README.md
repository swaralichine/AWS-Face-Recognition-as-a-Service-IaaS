# Cloud-Computing-Project--1

## IaaS using Amazon Web Services

### Team Members
- Aditya Deepak Bhat (1222133796)
- Radhika Kulkarni (1222165776)
- Swarali Chine (1222583687)

The aim of this project is to develop an application that provides a face recognition service to users. The application uses a deep learning model to perform facial recognition on the images provided to the model. The application is built to handle efficient processing of multiple requests concurrently and is able to scale-in and scale-out based on the demand.

The following AWS services were used in this project: Elastic Compute Cloud (EC2), Simple Storage Service (S3), and Simple Queue Service (SQS)
Please refer to the report for more details.

## Setup Details and Execution Steps

* S3 Buckets used:
    - Input Bucket - ccproject1inputbucket 
    - Output Bucket - ccproject2outputbucket

* SQS Queues used:
    - Input Queue - ccproject1inputqueue
    - Output Queue -  ccproject1outputqueue

### Requirements
- AWS Access to AMI (ID: ami-0a55e620aa5c79a24, Name: worker-1, Region: us-east-1)
- java-1.8.0 JRE and JDK 

### Setup of Web Tier
- To create the instance for the web tier, we have used the following instance type: Ubuntu Server 20.04 LTS (HVM), SSD Volume Type - ami-04505e74c0741db8d (64-bit x86) and location as us-east-1.
- Install the java JRE and JDK using: sudo yum install java-1.8.0
- Verify that java is installed correctly using the cli – java -version
- Create a jar file of the CCProjectWebTier module using maven build on your local machine.
- Transfer the generated jar file to the /home/ec2-user/ path in the web tier EC2 instance created in step 1.
- Set the jar file permissions using chmod +x <jar_file>
- Transfer the autoStartWebTier.sh shell script into the /var/lib/cloud/scripts/per-boot/ path in the web tier instance. This will automatically start the web tier application through the jar file on boot up of the instance.

### Setup of App Tier
- For the app tier, we have used the provided AMI (ID: ami-0a55e620aa5c79a24, Name: worker-1, Region: us-east-1).
- Install the java JRE and JDK using: sudo yum install java-1.8.0
- Verify that java is installed correctly using the cli – java -version
- Create a jar file of the CCProjectAppTierScale module using maven build on your local machine.
- Transfer the generated jar file to the /home/ec2-user/ path in the app tier EC2 instance created in step 1.
- Set the jar file permissions using chmod +x <jar_file>
- Transfer the autoStartAppTierScale.sh shell script into the /var/lib/cloud/scripts/per-boot/ path in the app tier instance. This will automatically start the app tier application through the jar file on boot up of the instance.
- Now create an AMI of the app tier instance. This will save a snapshot of the instance with the required environment, which will serve as the base image for all app tier instances.

To start the web tier application to serve requests for the end user, we simply start the web tier instance which will automatically start the web tier application through the jar file that was created. We can now use the workload generator to send requests to the REST API endpoint in the web tier. 

Any changes needed to parameters like bucket/queue names, access key, AMI ID, etc., can be done by updating the constants for the same defined in the UtilityConstants.java file.

### Testing the application with the provided workload generator:

* IP of Web Tier - 3.220.107.238
* Port Number - 8080
* REST API Endpoint name - /facialRecognition
* Endpoint URL - http://3.220.107.238:8080/facialRecognition

* command to test the application:
```
python3 multithread_workload_generator_verify_results_updated.py \
 --num_request 100 \
 --url 'http://3.220.107.238:8080/facialRecognition' \
 --image_folder "your_local_image_folder" &
```
