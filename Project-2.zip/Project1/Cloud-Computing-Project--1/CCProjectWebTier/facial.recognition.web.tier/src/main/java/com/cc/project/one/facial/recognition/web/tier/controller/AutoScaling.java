package com.cc.project.one.facial.recognition.web.tier.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.cc.project.one.facial.recognition.web.tier.service.helper.Ec2Helper;
import com.cc.project.one.facial.recognition.web.tier.service.helper.SqsHelper;

@Component
public class AutoScaling {
	
	final static Logger LOG = LoggerFactory.getLogger(AutoScaling.class);
	
	private static final Integer MAX_INSTANCES_ALLOWED = 19;
	
	SqsHelper sqsHelper;
	Ec2Helper ec2Helper;
	
	public AutoScaling() {
		this.sqsHelper = new SqsHelper();
		this.ec2Helper = new Ec2Helper();
	}

	@Scheduled(fixedDelay = 5000)
	public void autoscale() {
		int numberOfMessages = sqsHelper.getNumberOfMessagesOnInputQueue();
		LOG.info("There are " + numberOfMessages + " messages on the input queue.");
		
		int numberOfInstancesRunning = ec2Helper.getNumberOfInstancesRunning() - 1;
		LOG.info("There are " + numberOfInstancesRunning + " instances currently running.");

		if(numberOfInstancesRunning < MAX_INSTANCES_ALLOWED) {
			if(numberOfMessages > numberOfInstancesRunning) {
				int remaining = MAX_INSTANCES_ALLOWED - numberOfInstancesRunning;
				int difference = Math.min(numberOfMessages - numberOfInstancesRunning, remaining);
				LOG.info("Starting " + difference + " number of app tier scale instances.");
				
				List<String> stoppedInstances = ec2Helper.getInstancesInStopState();				
				if(difference > stoppedInstances.size()) {
					int createMore = difference - stoppedInstances.size();
					
					LOG.info("Creating " + createMore + " instances.");
					ec2Helper.startAppTierScaleInstances(createMore);
					
					LOG.info("Reusing " + stoppedInstances.size() + " instances.");
					ec2Helper.reuseInstances(stoppedInstances.size(), stoppedInstances);
				} else {
					LOG.info("Reusing " + difference + " instances.");
					ec2Helper.reuseInstances(difference, stoppedInstances);
				}
			}
		}
	}
}