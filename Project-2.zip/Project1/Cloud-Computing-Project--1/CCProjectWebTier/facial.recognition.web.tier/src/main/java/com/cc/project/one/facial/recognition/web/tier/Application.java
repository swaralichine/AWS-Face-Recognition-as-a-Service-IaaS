package com.cc.project.one.facial.recognition.web.tier;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.cc.project.one.facial.recognition.web.tier.controller.WebTier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SpringBootApplication
@Configuration
@ComponentScan("com.cc.project.one.facial.recognition.web.tier.*")
@EnableScheduling
public class Application {
	
	private final static Logger LOG = LoggerFactory.getLogger(Application.class);
	
	private static WebTier listenerToOutputQueue = new WebTier();

	public static void main(String[] args) {
		
		SpringApplication.run(Application.class, args);
		LOG.info("Application Started...");

		try {
			listenerToOutputQueue.listener();
		} catch (Exception e) {
			LOG.info("Output Queue Listener and Auto Scale Controller is not running.");
		}
	}
	
}