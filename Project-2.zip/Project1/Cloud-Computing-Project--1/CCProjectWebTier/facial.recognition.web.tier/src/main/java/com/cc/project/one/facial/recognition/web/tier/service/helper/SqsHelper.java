package com.cc.project.one.facial.recognition.web.tier.service.helper;

import java.util.List;
import java.util.Map;

import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.DeleteMessageRequest;
import com.amazonaws.services.sqs.model.GetQueueAttributesRequest;
import com.amazonaws.services.sqs.model.GetQueueAttributesResult;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.QueueAttributeName;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.amazonaws.services.sqs.model.SendMessageRequest;

import static com.cc.project.one.facial.recognition.web.tier.util.UtilityConstants.REGION;
import static com.cc.project.one.facial.recognition.web.tier.util.UtilityConstants.INPUT_QUEUE_NAME;
import static com.cc.project.one.facial.recognition.web.tier.util.UtilityConstants.OUTPUT_QUEUE_NAME;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SqsHelper extends AwsInitializer {
	
	// TODO: why is messageGroupId needed?
	
	private static AmazonSQS sqsClient;
	final Logger LOG = LoggerFactory.getLogger(SqsHelper.class);
	
	public SqsHelper() {
		sqsClient = getSqsClient();
	}
	
	private AmazonSQS getSqsClient() {
		AmazonSQS sqsClient = AmazonSQSClientBuilder
								.standard()
								.withRegion(REGION)
								.withCredentials(getAwsCredentials())
								.build();
		return sqsClient;
	}
	 
	 public void sendInputRequestToInputQueue(String request, String deduplicationId) {	
		 String inputQueueUrl = sqsClient.getQueueUrl(INPUT_QUEUE_NAME).getQueueUrl();
		 SendMessageRequest sendMessageRequest = new SendMessageRequest()
													.withQueueUrl(inputQueueUrl)
													//.withMessageGroupId("dummy")
													.withMessageBody(request);
													//.withMessageDeduplicationId(deduplicationId);
		 sqsClient.sendMessage(sendMessageRequest);
		 LOG.info("Input request sent to input queue.");
	 }
	 
	 public List<Message> listenToOutputSqs() {
		 String outputQueueUrl = sqsClient.getQueueUrl(OUTPUT_QUEUE_NAME).getQueueUrl();
		 ReceiveMessageRequest receiveMessageRequest = new ReceiveMessageRequest()
	    													.withQueueUrl(outputQueueUrl)
	    													.withMaxNumberOfMessages(10);
		List<Message> messages = sqsClient.receiveMessage(receiveMessageRequest).getMessages();
		if(messages == null || messages.size() == 0) {
			return null;
		}
		return messages;
	 }
	 
	 public void deleteFromOutputQueue(Message message) {
		String outputQueueUrl = sqsClient.getQueueUrl(OUTPUT_QUEUE_NAME).getQueueUrl();
		String messageReceiptHandle = message.getReceiptHandle();
		DeleteMessageRequest deleteMessageRequest = new DeleteMessageRequest(outputQueueUrl, messageReceiptHandle);
		sqsClient.deleteMessage(deleteMessageRequest);
	}
	 
	public Integer getNumberOfMessagesOnInputQueue() {
		LOG.info("Checking number of messages on the input queue.");
		
		String inputQueueUrl = sqsClient.getQueueUrl(INPUT_QUEUE_NAME).getQueueUrl();
		Integer count = 0;
		
		GetQueueAttributesRequest attributesRequest = new GetQueueAttributesRequest()
															.withQueueUrl(inputQueueUrl)
															.withAttributeNames(QueueAttributeName.ApproximateNumberOfMessages);
		GetQueueAttributesResult response = sqsClient.getQueueAttributes(attributesRequest);
		
		Map<String, String> attributeMap = response.getAttributes();
		count = Integer.valueOf((String) attributeMap.get("ApproximateNumberOfMessages"));		
		
		return count;
	}
}
