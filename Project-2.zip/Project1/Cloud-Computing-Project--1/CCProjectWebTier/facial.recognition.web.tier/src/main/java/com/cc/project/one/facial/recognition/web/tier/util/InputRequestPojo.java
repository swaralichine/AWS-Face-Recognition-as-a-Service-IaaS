package com.cc.project.one.facial.recognition.web.tier.util;

import java.util.Base64;

public class InputRequestPojo {
	
	String imageName;
	byte[] imageAsBytes;
	String image;
	
	public InputRequestPojo(String imageName, byte[] imageAsBytes) {
		this.imageName = imageName;
		this.imageAsBytes = imageAsBytes;
		this.image = Base64.getEncoder().encodeToString(imageAsBytes);
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public byte[] getImageAsBytes() {
		return imageAsBytes;
	}

	public void setImageAsBytes(byte[] imageAsBytes) {
		this.imageAsBytes = imageAsBytes;
	}	
	
	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}
	
	public String toString() {
		String s = imageName + ":::" + image;
		return s;
	}
	
	public static InputRequestPojo getObject(String s) {
		String[] sArray = s.split(":::");
		
		String imageName = sArray[0];
		byte[] imageAsBytes = Base64.getDecoder().decode(sArray[1]);
		 
		InputRequestPojo obj = new InputRequestPojo(imageName, imageAsBytes);
		
		return obj;
	}
	
}