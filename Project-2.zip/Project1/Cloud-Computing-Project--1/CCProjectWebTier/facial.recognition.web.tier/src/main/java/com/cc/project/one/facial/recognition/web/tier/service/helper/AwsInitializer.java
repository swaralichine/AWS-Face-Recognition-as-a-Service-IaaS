package com.cc.project.one.facial.recognition.web.tier.service.helper;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;

import static com.cc.project.one.facial.recognition.web.tier.util.UtilityConstants.ACCESS_KEY;
import static com.cc.project.one.facial.recognition.web.tier.util.UtilityConstants.ACCESS_ID;

public class AwsInitializer {

	public static AWSStaticCredentialsProvider getAwsCredentials() {
    	BasicAWSCredentials awsCredential = new BasicAWSCredentials(ACCESS_KEY, ACCESS_ID);
    	AWSStaticCredentialsProvider awsCredentialProvider = new AWSStaticCredentialsProvider(awsCredential);
    	return awsCredentialProvider;
    }
	
}