package com.cc.project.one.facial.recognition.web.tier.controller;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.services.sqs.model.Message;
import com.cc.project.one.facial.recognition.web.tier.service.helper.SqsHelper;
import com.cc.project.one.facial.recognition.web.tier.util.InputRequestPojo;

@RestController
@Component
public class WebTier {
	
	private SqsHelper sqsHelper;
	
	private final static Logger LOG = LoggerFactory.getLogger(WebTier.class);

	// key is imageName and value is output
	// to be used for returning responses back to the user
	public static HashMap<String, String> requestMapping;

	public WebTier() {
		this.sqsHelper = new SqsHelper();
		this.requestMapping = new HashMap<>();
	}

	@RequestMapping(value = "/status")
	public ResponseEntity<String> statusCheck() {
		String responseMessage = "Application is running.";
		LOG.info(responseMessage);
		ResponseEntity<String> status = new ResponseEntity<>(responseMessage, HttpStatus.OK);
		return status;
	}	

	@RequestMapping(value = "/facialRecognition", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<String> landingPage(@RequestParam("myfile") MultipartFile inputRequest) throws IOException {
		String fileName = inputRequest.getOriginalFilename();
		InputRequestPojo inputRequestObject = new InputRequestPojo(fileName, inputRequest.getBytes());
		String deduplicationId = fileName + LocalDateTime.now();
		LOG.info("Received " + fileName + " Request.");

		sqsHelper.sendInputRequestToInputQueue(inputRequestObject.toString(), deduplicationId);
		LOG.info("Input Request for " + fileName + " put on the queue.");
		
		String output = null;
		while(true) {
			if(requestMapping.containsKey(fileName)) {
				output = requestMapping.get(fileName);
				requestMapping.remove(fileName);
				LOG.info("Received - " + fileName + ":" + output);
				LOG.info("Returning output for " + fileName + " to user.");
				return new ResponseEntity<String>(output, HttpStatus.OK);
			}
		}
	}
	
	@Scheduled(fixedDelay = 3000)
	public void listener() throws Exception {
		LOG.info("Output Queue Listener is listening to the output queue....");
		List<Message> messages = sqsHelper.listenToOutputSqs();
		if(messages != null && messages.size() != 0) {
			LOG.info("Retrieved " + messages.size() + " from the output queue.");
			for(Message message : messages) {
				sqsHelper.deleteFromOutputQueue(message);
				String[] content = message.getBody().split(",");
				String key = content[0];
				String value = content[1];
				LOG.info("Putting output for " + key + ", " + value + " on the map.");
				requestMapping.put(key, value);
			}			
		}
	}
}