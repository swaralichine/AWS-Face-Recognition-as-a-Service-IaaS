package com.cc.project.one.facial.recognition.web.tier.service.helper;

import static com.cc.project.one.facial.recognition.web.tier.util.UtilityConstants.REGION;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2ClientBuilder;
import com.amazonaws.services.ec2.model.DescribeInstancesRequest;
import com.amazonaws.services.ec2.model.DescribeInstancesResult;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.InstanceStateName;
import com.amazonaws.services.ec2.model.InstanceType;
import com.amazonaws.services.ec2.model.Reservation;
import com.amazonaws.services.ec2.model.RunInstancesRequest;
import com.amazonaws.services.ec2.model.RunInstancesResult;
import com.amazonaws.services.ec2.model.StartInstancesRequest;
import com.amazonaws.services.ec2.model.Tag;
import com.amazonaws.services.ec2.model.TagSpecification;

import static com.cc.project.one.facial.recognition.web.tier.util.UtilityConstants.AMI_ID;;

public class Ec2Helper extends AwsInitializer {
	
	final static Logger LOG = LoggerFactory.getLogger(Ec2Helper.class);
    AmazonEC2 ec2Client;
	
	public Ec2Helper() {
        this.ec2Client = getEc2Client();
    }

    private AmazonEC2 getEc2Client() {
        AmazonEC2 ec2Client = AmazonEC2ClientBuilder.standard()
                                .withRegion(REGION)
                                .withCredentials(getAwsCredentials())
                                .build();
        return ec2Client;
    }
    
    public Integer getNumberOfInstancesRunning() {
    	LOG.info("Checking the number of instances currently running.");
    	
    	Integer count = 0;
    	boolean done = true;
    	
    	DescribeInstancesRequest describeInstanceRequest = new DescribeInstancesRequest();
    	
    	while(done) {
    		DescribeInstancesResult describeInstanceResponse = ec2Client.describeInstances(describeInstanceRequest);
        	for(Reservation reservation : describeInstanceResponse.getReservations()) {
                for(Instance instance : reservation.getInstances()) {
                	if(instance.getState().getName().equals(InstanceStateName.Running.toString())
                	|| instance.getState().getName().equals(InstanceStateName.Pending.toString())
                	|| instance.getState().getName().equals(InstanceStateName.Stopping.toString())) {
                		count++;
                	}
                }            
            }
        	describeInstanceRequest.setNextToken(describeInstanceResponse.getNextToken());
            if(describeInstanceResponse.getNextToken() == null) {
                done = false;
            }
    	}
    	
    	return count;
    }
    
    public List<String> getInstancesInStopState() {
    	LOG.info("Getting list of stopped instances.");
    	List<String> stoppedInstances = new ArrayList<>();
    	boolean done = true;
    	
    	DescribeInstancesRequest describeInstanceRequest = new DescribeInstancesRequest();
    	
    	while(done) {
    		DescribeInstancesResult describeInstanceResponse = ec2Client.describeInstances(describeInstanceRequest);
        	for(Reservation reservation : describeInstanceResponse.getReservations()) {
                for(Instance instance : reservation.getInstances()) {
                	if(instance.getState().getName().equals(InstanceStateName.Stopped.toString())) {
                		stoppedInstances.add(instance.getInstanceId());
                	}
                }            
            }
        	describeInstanceRequest.setNextToken(describeInstanceResponse.getNextToken());
            if(describeInstanceResponse.getNextToken() == null) {
                done = false;
            }
    	}
    	
    	return stoppedInstances;
    }
    
    public void reuseInstances(int count, List<String> instanceIds) {
    	if(count == 0) {
    		return;
    	}
    	
    	int i = 0;
    	while(i < count) {
    		String instanceId = instanceIds.get(i);
    		StartInstancesRequest startInstanceRequest = new StartInstancesRequest().withInstanceIds(instanceId);
        	ec2Client.startInstances(startInstanceRequest);
        	i++;
    	}
    }
    
    public void startAppTierScaleInstances(int count) {
    	if(count == 0) {
    		return;
    	}
    	List<String> securityGroupIds = new ArrayList<>();
    	securityGroupIds.add("sg-0eada259404b66f74");
    	
    	Collection<TagSpecification> tagSpecifications = new ArrayList<TagSpecification>();
		TagSpecification tagSpecification = new TagSpecification();
		Collection<Tag> tags = new ArrayList<Tag>();
		Tag tag = new Tag();
		tag.setKey("Name");
		tag.setValue("AppTier");
		tags.add(tag);
		tagSpecification.setResourceType("instance");
		tagSpecification.setTags(tags);
		tagSpecifications.add(tagSpecification);
    	
    	RunInstancesRequest runInstanceRequest = new RunInstancesRequest(AMI_ID, 1, count);
    	runInstanceRequest.setInstanceType(InstanceType.T2Micro);
    	runInstanceRequest.setSecurityGroupIds(securityGroupIds);
    	runInstanceRequest.setKeyName("cse546");
    	runInstanceRequest.setTagSpecifications(tagSpecifications);
    	
    	RunInstancesResult result = null;
		try {
			result = ec2Client.runInstances(runInstanceRequest);
		} catch (Exception e) {
			LOG.error("Unable to create app tier instances.");
			e.printStackTrace();
		}
		LOG.info("Created " + count + " app tier instances.");
    }

}