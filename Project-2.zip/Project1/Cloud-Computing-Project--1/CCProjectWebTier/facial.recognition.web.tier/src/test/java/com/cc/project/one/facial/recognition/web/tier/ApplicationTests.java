package com.cc.project.one.facial.recognition.web.tier;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ApplicationTests.class)
class ApplicationTests {

	@Test
	void contextLoads() {
	}

}