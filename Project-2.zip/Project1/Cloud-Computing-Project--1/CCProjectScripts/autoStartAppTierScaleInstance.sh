 #! /usr/bin/sh

    PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin
    JAVA=/usr/bin/java
    MY_SERVER=/home/ec2-user/facial.recognition.app.tier.scale-0.0.1-SNAPSHOT.jar
    USER=ec2-user
    /bin/su - $USER -c "$JAVA -jar $MY_SERVER &"