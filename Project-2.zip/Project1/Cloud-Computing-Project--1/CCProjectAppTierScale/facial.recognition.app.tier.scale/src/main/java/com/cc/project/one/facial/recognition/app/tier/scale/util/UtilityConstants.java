package com.cc.project.one.facial.recognition.app.tier.scale.util;

public class UtilityConstants {

    public static final String REGION = "us-east-1";
    
//	public static final String INPUT_QUEUE_NAME = "ccproject1inputqueue.fifo";
//	public static final String OUTPUT_QUEUE_NAME = "ccproject1outputqueue.fifo";
	public static final String INPUT_QUEUE_NAME = "ccproject1inputqueue";
	public static final String OUTPUT_QUEUE_NAME = "ccproject1outputqueue";

    public static final String INPUT_BUCKET_NAME = "ccproject1inputbucket";
    public static final String OUTPUT_BUCKET_NAME = "ccproject1outputbucket";

    public static final String ACCESS_KEY = "AKIA5DMPX2JVJVBBASWS";
    public static final String ACCESS_ID = "XNOZbCRi1rkq3ZUnVho2PIJTph0w3yUo/sfQX6K/";
}