package com.cc.project.one.facial.recognition.app.tier.scale.service.helper;

import static com.cc.project.one.facial.recognition.app.tier.scale.util.UtilityConstants.INPUT_BUCKET_NAME;
import static com.cc.project.one.facial.recognition.app.tier.scale.util.UtilityConstants.OUTPUT_BUCKET_NAME;
import static com.cc.project.one.facial.recognition.app.tier.scale.util.UtilityConstants.REGION;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.cc.project.one.facial.recognition.app.tier.scale.service.helper.S3Helper;

public class S3Helper extends AwsInitializer {
	
    private static final Logger LOG = LoggerFactory.getLogger(S3Helper.class);

    private AmazonS3 s3Client;

    public S3Helper() {
		s3Client = getS3Client();
		if(s3Client == null) {
			throw new RuntimeException("s3Client is null");
		}
	}
	
	private static AmazonS3 getS3Client() {
		AmazonS3 s3Client = null;
		try {
			s3Client =  AmazonS3ClientBuilder
							.standard()
							.withRegion(REGION)
							.withCredentials(getAwsCredentials())
							.build();
		} catch (Exception e) {
			LOG.error("Unable to create s3Client.");
			e.printStackTrace();
		}
    	
    	return s3Client;
    }

	public void putOutputOnOutputBucket(String imageName, String value) {
    	String key = imageName.split("\\.")[0];
    	
        ObjectMetadata meta = new ObjectMetadata();
        meta.setContentMD5(new String(com.amazonaws.util.Base64.encode(DigestUtils.md5(value))));
        meta.setContentLength(value.length());
        
        InputStream stream = new ByteArrayInputStream(value.getBytes(StandardCharsets.UTF_8));
        
        PutObjectRequest putObjectRequest = new PutObjectRequest(OUTPUT_BUCKET_NAME, key, stream, meta);
        try {
        	PutObjectResult putObjectResult = s3Client.putObject(putObjectRequest);
        } catch (Exception e) {
        	LOG.error("Unable to put output on output S3 bucket.");
        	e.printStackTrace();
        }
        
        LOG.info("Output Image has been put in S3 Output Bucket");
    } 
    
    public void putImageToInputBucket(byte[] imageInput, String imageName) {
    	ByteArrayInputStream imageInputStream = new ByteArrayInputStream(imageInput);
    	
    	ObjectMetadata meta = new ObjectMetadata();
		meta.setContentLength(imageInput.length);
		
        PutObjectRequest putObjectRequest = new PutObjectRequest(INPUT_BUCKET_NAME, imageName, imageInputStream, meta);
        try {
        	PutObjectResult putObjectResult = s3Client.putObject(putObjectRequest);
        } catch (Exception e) {
        	LOG.error("Unable to put input image input on S3 bucket.");
        	e.printStackTrace();
        }         
        
        LOG.info("Input Image has been put in S3 Input Bucket");
    }
}