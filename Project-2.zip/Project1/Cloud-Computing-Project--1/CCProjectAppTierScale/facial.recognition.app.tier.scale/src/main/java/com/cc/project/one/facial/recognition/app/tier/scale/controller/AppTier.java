package com.cc.project.one.facial.recognition.app.tier.scale.controller;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;

import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.util.EC2MetadataUtils;
import com.cc.project.one.facial.recognition.app.tier.scale.service.helper.Ec2Helper;
import com.cc.project.one.facial.recognition.app.tier.scale.service.helper.S3Helper;
import com.cc.project.one.facial.recognition.app.tier.scale.service.helper.SqsHelper;
import com.cc.project.one.facial.recognition.app.tier.scale.util.InputRequestPojo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppTier {

     private static final String LOCAL_FOLDER_PATH = "/home/ec2-user/";
     final Logger LOG = LoggerFactory.getLogger(AppTier.class);

     private SqsHelper sqsHelper;
     private S3Helper s3Helper;
     private Ec2Helper ec2Helper;

     private String instanceId;

     public AppTier() {
         this.sqsHelper = new SqsHelper();
         this.s3Helper = new S3Helper();
         this.ec2Helper = new Ec2Helper();
         this.instanceId = EC2MetadataUtils.getInstanceId();
     }

    // entry point
    public void controller() throws Exception {
    	int retry = 0;
        while(true) {
            Message inputMessage = sqsHelper.listenToInputSqs();
            if(inputMessage == null) {
                if(retry == 2) {
                    break;
                }
                Thread.sleep(2000);
                retry++;
                continue;
            }
            
            sqsHelper.deleteFromInputQueue(inputMessage);
            retry = 0;
            String inputRequestAsString = inputMessage.getBody();
            InputRequestPojo inputRequestPojo = InputRequestPojo.getObject(inputRequestAsString);
            String imageName = inputRequestPojo.getImageName();
            byte[] image = inputRequestPojo.getImageAsBytes();

            s3Helper.putImageToInputBucket(image, imageName);

            try {
                File file = new File(imageName);
                FileOutputStream fos = new FileOutputStream(file);
                ByteArrayInputStream imageInputStream = new ByteArrayInputStream(image);
                byte[] readBuffer = new byte[1024];
                int readLen = 0;
                while ((readLen = imageInputStream.read(readBuffer)) > 0) {
                    fos.write(readBuffer, 0, readLen);
                }
                imageInputStream.close();
                fos.close();
            } catch (Exception e) {
                LOG.error("Error creating local file of input image.");
                throw new RuntimeException("Error creating local file of input image.");
            }

            String imageUrl = new String(LOCAL_FOLDER_PATH + inputRequestPojo.getImageName());
            LOG.info("The image path is " + imageUrl);

            String output = facialRecognition(imageUrl);
            if (output == null) {
    			LOG.error("Received null output from facial recognition model.");
    			throw new RuntimeException("Received null output from facial recognition model.");
    		}
            s3Helper.putOutputOnOutputBucket(inputRequestPojo.getImageName(), output);
            sqsHelper.sendOutputToOutputQueue(inputRequestPojo.getImageName(), output);

            LOG.info("Processed image.");
        }
        LOG.info("Shutting down instance with id " + instanceId);
        ec2Helper.shutdownEc2Instance(instanceId);
    }

    private String facialRecognition(String imageUrl) {
        String output = null;
        Process proc;
        try {
            proc = new ProcessBuilder("python3", "face_recognition.py", imageUrl).start();
            proc.waitFor();
            BufferedReader br = new BufferedReader(new InputStreamReader(proc.getInputStream()));
            output = br.readLine();
            proc.destroy();
        } catch (Exception e) {
        	LOG.error("Not able to run facial recognition. Check error.");
			e.printStackTrace();
        }
        return output;
    }
}