package com.cc.project.one.facial.recognition.app.tier.scale.service.helper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2ClientBuilder;
import com.amazonaws.services.ec2.model.StopInstancesRequest;
import com.amazonaws.services.ec2.model.TerminateInstancesRequest;
import static com.cc.project.one.facial.recognition.app.tier.scale.util.UtilityConstants.REGION;

public class Ec2Helper extends AwsInitializer {

    final static Logger LOG = LoggerFactory.getLogger(Ec2Helper.class);
    private AmazonEC2 ec2Client;

    public Ec2Helper() {
        this.ec2Client = getEc2Client();
        if(ec2Client == null) {
        	throw new RuntimeException("ec2Client is null");
        }
    }

    private AmazonEC2 getEc2Client() {
    	AmazonEC2 ec2Client = null;
    	try {
    		ec2Client = AmazonEC2ClientBuilder.standard()
    						.withRegion(REGION)
    						.withCredentials(getAwsCredentials())
    						.build();
    	} catch (Exception e) {
    		LOG.error("Unable to create ec2Client.");
    		e.printStackTrace();
    	}
                                
        return ec2Client;
    }
    
    public void shutdownEc2Instance(String instanceId) {
    	try {
    		StopInstancesRequest request = new StopInstancesRequest().withInstanceIds(instanceId);
    		ec2Client.stopInstances(request);
    	} catch (Exception e) {
    		LOG.error("Unable to shut down instance.");
    		e.printStackTrace();
    	}
    	LOG.info("Shut down instance with id " + instanceId);
    }

    public void terminateEc2Instance(String instanceId) {
    	try {
            TerminateInstancesRequest terminateRequest = new TerminateInstancesRequest().withInstanceIds(instanceId);
            ec2Client.terminateInstances(terminateRequest);
    	} catch (Exception e) {
    		LOG.error("Unable to terminate instance.");
    		e.printStackTrace();
    	}
        LOG.info("Terminated instance with id " + instanceId);
    }
}
