package com.cc.project.one.facial.recognition.app.tier.scale.service.helper;

import static com.cc.project.one.facial.recognition.app.tier.scale.util.UtilityConstants.INPUT_QUEUE_NAME;
import static com.cc.project.one.facial.recognition.app.tier.scale.util.UtilityConstants.OUTPUT_QUEUE_NAME;
import static com.cc.project.one.facial.recognition.app.tier.scale.util.UtilityConstants.REGION;

import java.util.List;

import org.joda.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.DeleteMessageRequest;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.amazonaws.services.sqs.model.SendMessageRequest;

public class SqsHelper extends AwsInitializer {

	private static AmazonSQS sqsClient;

	private static final Logger LOG = LoggerFactory.getLogger(SqsHelper.class);
	
	public SqsHelper() {
		sqsClient = getSqsClient();
		if(sqsClient == null) {
			throw new RuntimeException("sqsClient is null.");
		}
	}
	
	private static AmazonSQS getSqsClient() {
		AmazonSQS sqsClient = null;
		try {
			sqsClient = AmazonSQSClientBuilder
						.standard()
						.withRegion(REGION)
						.withCredentials(getAwsCredentials())
						.build();
		} catch (Exception e) {
			LOG.error("Unable to create sqsClient.");
			e.printStackTrace();
		}
		
		return sqsClient;
	}
	
	public Message listenToInputSqs() {
    	String inputQueueUrl = sqsClient.getQueueUrl(INPUT_QUEUE_NAME).getQueueUrl();

    	ReceiveMessageRequest receiveMessageRequest = new ReceiveMessageRequest()
    														.withQueueUrl(inputQueueUrl)
    														.withMaxNumberOfMessages(1);
    	List<Message> messages = null;
    	try {
    		messages = sqsClient.receiveMessage(receiveMessageRequest).getMessages();
    	} catch (Exception e) {
    		LOG.error("Unable to retrieve input from the input queue.");
    		e.printStackTrace();
    	}
		if(messages == null || messages.size() == 0) {
			return null;
		}
		LOG.info("Received input message from input queue.");
		return messages.get(0);
    }

	public void sendOutputToOutputQueue(String key, String value) {
		String outputQueueUrl = sqsClient.getQueueUrl(OUTPUT_QUEUE_NAME).getQueueUrl();
		
		StringBuilder message = new StringBuilder();
		message.append(key);
		message.append(",");
		message.append(value);
		//String deduplicationId = key + LocalDateTime.now();
		
		SendMessageRequest sendMessageRequest = new SendMessageRequest()
													.withQueueUrl(outputQueueUrl)
													//.withMessageGroupId("dummy")
													.withMessageBody(message.toString());
													//.withMessageDeduplicationId(deduplicationId);
		try {
			sqsClient.sendMessage(sendMessageRequest);
		} catch (Exception e) {
			LOG.error("Unable to send output to output queue.");
			e.printStackTrace();
		}
		LOG.info("Output has been put on output queue.");
	}

	public void deleteFromInputQueue(Message inputMessage) {
		String inputQueueUrl = sqsClient.getQueueUrl(INPUT_QUEUE_NAME).getQueueUrl();
		String messageReceiptHandle = inputMessage.getReceiptHandle();
		DeleteMessageRequest deleteMessageRequest = new DeleteMessageRequest(inputQueueUrl, messageReceiptHandle);
		try {
			sqsClient.deleteMessage(deleteMessageRequest);
		} catch (Exception e) {
			LOG.error("Unable to delete input message from input queue.");
			e.printStackTrace();
		}
		LOG.info("Input message deleted from input queue.");
    }
}