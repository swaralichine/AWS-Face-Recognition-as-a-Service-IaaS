package com.cc.project.one.facial.recognition.app.tier.scale.service.helper;

import static com.cc.project.one.facial.recognition.app.tier.scale.util.UtilityConstants.ACCESS_ID;
import static com.cc.project.one.facial.recognition.app.tier.scale.util.UtilityConstants.ACCESS_KEY;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;

public class AwsInitializer {

	public static AWSStaticCredentialsProvider getAwsCredentials() {
    	BasicAWSCredentials awsCredential = new BasicAWSCredentials(ACCESS_KEY, ACCESS_ID);
    	AWSStaticCredentialsProvider awsCredentialProvider = new AWSStaticCredentialsProvider(awsCredential);
    	return awsCredentialProvider;
    }

}